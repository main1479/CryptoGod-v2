# Bootstrap Starter Pack

This starter pack I created for my Bootstrap project, then I see lots of people asking for the easiest way to start a Bootstrap project quickly. so here it is.
just open this folder on your terminal then write npm install. When the installation is complete just write this command npm start
#   C r y p t o G o d - v 2  
 